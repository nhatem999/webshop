<?php

function construct() {
    load_model('index');
    load('lib','validation');
    load('helper','url');
    load('lib','email');
    
}

function indexAction() {
    load_view('index');

}

function addAction() {
   
}

function editAction() {
    
}
