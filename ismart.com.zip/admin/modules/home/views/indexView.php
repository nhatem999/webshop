<?php
    get_header();
?>
<div id="content">
    <?php show_array($_SESSION); ?>
 </div>

<?php
    get_footer();
?>